def loadmodel(path):
    return